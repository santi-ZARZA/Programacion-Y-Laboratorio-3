<?php

require_once "Usuario.php";
require_once "AccesoDatos.php";

/*
try {
$conectar = new PDO('mysql:host=localhost;dbname=cdcol;',"root","");

    //echo "me conecte";
    //echo "El usuario 'root' con contraseña '' se conecto exitosamente.";

    $array = $conectar->query("SELECT * FROM cds");

    $datos = $array->fetchall(PDO::);

    foreach ($datos as $value) {
        var_dump($value)."<br/><br/>";
    }

    //var_dump($datos);
} catch (PDOException $th) {
    echo $th->GetMessage();
}*/


$usu1 = new Usuario(1,"usu@gmail.com","aaa","usu","ario",2);

var_dump($usu1->Traer(1));

//$usu1->TraerTodos();

//echo Usuario::Eliminar();

//echo Usuario::Agregar($usu1);

//echo Usuario::Modificar($usu1);
