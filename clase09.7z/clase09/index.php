<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require_once './vendor/autoload.php';

$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;


use Firebase\JWT\JWT;
/*
¡La primera línea es la más importante! A su vez en el modo de 
desarrollo para obtener información sobre los errores
 (sin él, Slim por lo menos registrar los errores por lo que si está utilizando
  el construido en PHP webserver, entonces usted verá en la salida de la consola 
  que es útil).

  La segunda línea permite al servidor web establecer el encabezado Content-Length, 
  lo que hace que Slim se comporte de manera más predecible.
*/

$app = new \Slim\App(["settings" => $config]);

$app->post('/crear', function (Request $request, Response $response) {
  $params = $request->getparsedbody();
  $user = array('nombre' => $params["nombre"], 'apellido' => $params["apellido"], 'division' => $params["division"]);

  $token = JWT::encode($user,"claveSuperSecreta");

  return $response->withJson($token,200);
});

$app->post('/verificar', function (Request $request, Response $response) {
  $params = $request->getparsedbody();
  $token = $params["token"];

  if (empty($token) || $token === "") {
    throw new Exception("el token esta vacio.");
  }

  try {
    $decodificado = JWT::decode(
      $token,
      "claveSuperSecreta",
      ["HS256"]
    );

  } catch (Exception $th) {
    throw new Exception("Token no Valido....!!!!",$th->getMessage());
  }

  return "Token Ok!!!";
});

$app->post('/obtenerPayload', function (Request $request, Response $response) {
  $params = $request->getparsedbody();
  $token = $params["token"];

  if (empty($token) || $token === "") {
    throw new Exception("el token esta vacio.");
  }

  try {
    $decodificado = JWT::decode(
      $token,
      "claveSuperSecreta",
      ["HS256"]
    );

  } catch (Exception $th) {
    throw new Exception("Token no Valido....!!!!",$th->getMessage());
  }

  return $response->withJson($decodificado,200);
});
$app->run();